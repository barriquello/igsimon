var searchData=
[
  ['fp',['FP',['../namespace_interface_desktop.html#af376de2af25fbcbc7f20f9846a7d4913a4ebada6a2af2bcba53ded1d7b414f081',1,'InterfaceDesktop']]],
  ['fp0',['FP0',['../namespace_interface_desktop.html#af376de2af25fbcbc7f20f9846a7d4913a2c28216d0a3cc556dee55e37a12add01',1,'InterfaceDesktop']]],
  ['fr',['Fr',['../namespace_interface_desktop.html#af376de2af25fbcbc7f20f9846a7d4913afa717ba17306cd76900510df8ac8013e',1,'InterfaceDesktop']]],
  ['fr0',['Fr0',['../namespace_interface_desktop.html#af376de2af25fbcbc7f20f9846a7d4913a06c0982e7d97565d0292b3ebdecd8f0c',1,'InterfaceDesktop']]],
  ['frmcomparacao',['frmComparacao',['../namespace_interface_desktop.html#a7c7f3613d058af20cc8fec119a16fb99a91bd1129240866756482ff1236524caa',1,'InterfaceDesktop']]],
  ['frmgraficos',['frmGraficos',['../namespace_interface_desktop.html#a7c7f3613d058af20cc8fec119a16fb99a275420b771b67d12c2323889a631ad60',1,'InterfaceDesktop']]],
  ['frmmain',['frmMain',['../namespace_interface_desktop.html#a7c7f3613d058af20cc8fec119a16fb99a58b288c8a50733cded08625777af3b6b',1,'InterfaceDesktop']]]
];
