var searchData=
[
  ['ni',['Ni',['../namespace_interface_desktop.html#af376de2af25fbcbc7f20f9846a7d4913aa26e174e330476756d2601ea5368aec3',1,'InterfaceDesktop']]],
  ['ni0',['Ni0',['../namespace_interface_desktop.html#af376de2af25fbcbc7f20f9846a7d4913a3cb6ddf32d4ba16a14adb6d0990fabea',1,'InterfaceDesktop']]],
  ['nodetv1',['NodeTv1',['../class_interface_desktop_1_1_feed_servidor.html#af44aa02af3f4e28d72c1bb6a6bcfbd9b',1,'InterfaceDesktop::FeedServidor']]],
  ['nome',['Nome',['../class_interface_desktop_1_1_feed.html#abbabd9d818718d601591d70acdf783ba',1,'InterfaceDesktop::Feed']]],
  ['nomefeed',['NomeFeed',['../class_interface_desktop_1_1_feed_servidor.html#a3614df3d3bbfc5eac9e30884cb7d1b89',1,'InterfaceDesktop::FeedServidor']]],
  ['nometabela',['NomeTabela',['../class_interface_desktop_1_1_feed_servidor.html#a6a4995d4613553c7f94fde79d99baf76',1,'InterfaceDesktop::FeedServidor']]],
  ['numvars',['NumVars',['../class_interface_desktop_1_1_variaveis.html#aedc7e3796011f280e7089cf0e12185df',1,'InterfaceDesktop::Variaveis']]]
];
