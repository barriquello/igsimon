var searchData=
[
  ['username',['Username',['../class_interface_desktop_1_1_servidor.html#aea8636b5f056cce17d604d7503b2370b',1,'InterfaceDesktop::Servidor']]]
];
