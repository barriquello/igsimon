var searchData=
[
  ['variaveis',['Variaveis',['../class_interface_desktop_1_1_variaveis.html',1,'InterfaceDesktop']]]
];
