var searchData=
[
  ['apikey',['APIKey',['../class_interface_desktop_1_1_servidor.html#a5d05914be5aaf1c8eec4e6f445cf1ca9',1,'InterfaceDesktop::Servidor']]],
  ['ate',['aTe',['../class_interface_desktop_1_1frm_main.html#ae261b291d4b76e8735e18ed92109e0fd',1,'InterfaceDesktop::frmMain']]],
  ['ato',['aTo',['../class_interface_desktop_1_1frm_main.html#a17dad1ba37a5d830c9f42da052db08a7',1,'InterfaceDesktop::frmMain']]]
];
