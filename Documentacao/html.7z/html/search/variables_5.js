var searchData=
[
  ['encerrando',['Encerrando',['../class_interface_desktop_1_1frm_main.html#a38d651f06adde6937ca5e06ebbffa084',1,'InterfaceDesktop::frmMain']]],
  ['escalatamanho',['EscalaTamanho',['../class_interface_desktop_1_1_analogico.html#a0f2272a68dcf19acc13727cfc8e3fac0',1,'InterfaceDesktop::Analogico']]]
];
