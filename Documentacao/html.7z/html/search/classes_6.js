var searchData=
[
  ['registrocsv',['RegistroCSV',['../class_interface_desktop_1_1_registro_c_s_v.html',1,'InterfaceDesktop']]],
  ['registrodb',['RegistroDB',['../class_interface_desktop_1_1_registro_d_b.html',1,'InterfaceDesktop']]]
];
