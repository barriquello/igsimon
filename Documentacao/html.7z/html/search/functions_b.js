var searchData=
[
  ['permissoesdousuario',['PermissoesDoUsuario',['../class_interface_desktop_1_1_banco_de_dados.html#a394fe671c4bcb0d1a4430c270f1cfef8',1,'InterfaceDesktop::BancoDeDados']]],
  ['pic1_5fclick',['pic1_Click',['../class_interface_desktop_1_1frm_compara.html#ab45f4676a349d8f92e2813c56a34ac76',1,'InterfaceDesktop::frmCompara']]],
  ['pic2_5fclick',['pic2_Click',['../class_interface_desktop_1_1frm_compara.html#adcd4600145384ec0f245bf17bbf336ae',1,'InterfaceDesktop::frmCompara']]],
  ['plotagrafico',['PlotaGrafico',['../class_interface_desktop_1_1frm_graficos.html#a3652cb2b9442b917dcf044fa9ecab4c5',1,'InterfaceDesktop.frmGraficos.PlotaGrafico()'],['../class_interface_desktop_1_1frm_main.html#a427a81e77296cbe50030a04a8447114c',1,'InterfaceDesktop.frmMain.PlotaGrafico(UInt32 Start, UInt32 End)'],['../class_interface_desktop_1_1frm_main.html#a2542a785ef7101ea4a6e31f80b25bbf7',1,'InterfaceDesktop.frmMain.PlotaGrafico(DateTime dateTime1, DateTime dateTime2)']]]
];
