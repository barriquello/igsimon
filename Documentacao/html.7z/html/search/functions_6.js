var searchData=
[
  ['geragradico',['GeraGradico',['../class_interface_desktop_1_1frm_compara.html#a77cac778dc7ceed90c90c77fc99d1bb6',1,'InterfaceDesktop::frmCompara']]],
  ['geragrafico',['GeraGrafico',['../class_interface_desktop_1_1frm_graficos.html#ab0636d315aad019db420d030f1828731',1,'InterfaceDesktop::frmGraficos']]],
  ['gerargrafico',['GerarGrafico',['../class_interface_desktop_1_1frm_main.html#a2091070e6580f43f6c893f6c453435be',1,'InterfaceDesktop::frmMain']]],
  ['getcsv',['GetCSV',['../class_interface_desktop_1_1frm_main.html#ac5e66f32fe5240d47414734029171830',1,'InterfaceDesktop::frmMain']]],
  ['getmd5',['getMD5',['../class_interface_desktop_1_1_uteis.html#afe62d533351f7660c89167d0c6b482f0',1,'InterfaceDesktop::Uteis']]]
];
