var searchData=
[
  ['ovalshape1',['ovalShape1',['../class_interface_desktop_1_1_analogico.html#a845e3eb8cf881762b2a94d77fe3504d1',1,'InterfaceDesktop::Analogico']]]
];
