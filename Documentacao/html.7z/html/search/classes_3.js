var searchData=
[
  ['feed',['Feed',['../class_interface_desktop_1_1_feed.html',1,'InterfaceDesktop']]],
  ['feedservidor',['FeedServidor',['../class_interface_desktop_1_1_feed_servidor.html',1,'InterfaceDesktop']]],
  ['frmcompara',['frmCompara',['../class_interface_desktop_1_1frm_compara.html',1,'InterfaceDesktop']]],
  ['frmconfig',['frmConfig',['../class_interface_desktop_1_1frm_config.html',1,'InterfaceDesktop']]],
  ['frmgraficos',['frmGraficos',['../class_interface_desktop_1_1frm_graficos.html',1,'InterfaceDesktop']]],
  ['frmlogin',['frmLogin',['../class_interface_desktop_1_1frm_login.html',1,'InterfaceDesktop']]],
  ['frmmain',['frmMain',['../class_interface_desktop_1_1frm_main.html',1,'InterfaceDesktop']]]
];
