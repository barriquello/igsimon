var searchData=
[
  ['salvarcsv',['SalvarCSV',['../class_interface_desktop_1_1frm_main.html#af3c6b37b7f38183f4b6e6c3920d6cd5e',1,'InterfaceDesktop::frmMain']]],
  ['salvarxlsx',['SalvarXLSX',['../class_interface_desktop_1_1_salvar_excel.html#a425f716bf4f111b78e96fe2ff4f7e0b2',1,'InterfaceDesktop::SalvarExcel']]],
  ['senhadousuario',['SenhaDoUsuario',['../class_interface_desktop_1_1_banco_de_dados.html#a3c9f8c6fdaea86591f31393fb87558f4',1,'InterfaceDesktop::BancoDeDados']]],
  ['setpicture',['SetPicture',['../class_interface_desktop_1_1_analogico.html#a8180c0a472d6942e4ecd7cb7d443dacc',1,'InterfaceDesktop::Analogico']]],
  ['strvariaveis',['strVariaveis',['../class_interface_desktop_1_1_variaveis.html#a81c485dd5569c3ee0dd13ee56067dfaf',1,'InterfaceDesktop::Variaveis']]]
];
