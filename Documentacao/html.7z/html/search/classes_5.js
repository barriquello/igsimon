var searchData=
[
  ['json',['json',['../class_interface_desktop_1_1json.html',1,'InterfaceDesktop']]]
];
