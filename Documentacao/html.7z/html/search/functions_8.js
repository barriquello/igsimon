var searchData=
[
  ['janelatext',['JanelaText',['../class_interface_desktop_1_1frm_compara.html#aee812233be4564649151fb4f1fa0f2b9',1,'InterfaceDesktop::frmCompara']]],
  ['json2feed',['json2Feed',['../class_interface_desktop_1_1json.html#a0d1f176edfc6335f887f5782db8f7c64',1,'InterfaceDesktop::json']]]
];
