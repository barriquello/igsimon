var searchData=
[
  ['global',['Global',['../class_interface_desktop_1_1_global.html',1,'InterfaceDesktop']]]
];
