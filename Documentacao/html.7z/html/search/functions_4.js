var searchData=
[
  ['escolhecor',['escolheCor',['../class_interface_desktop_1_1frm_compara.html#a0d0eb11fd14d2b7eb1ea7b1d94db2bd4',1,'InterfaceDesktop::frmCompara']]],
  ['exibefloat',['ExibeFloat',['../class_interface_desktop_1_1frm_compara.html#ae89714a1132c66306b0734ef214807eb',1,'InterfaceDesktop::frmCompara']]]
];
