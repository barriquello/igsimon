var searchData=
[
  ['marcartodas',['MarcarTodas',['../class_interface_desktop_1_1frm_main.html#ad12a6746121ebb110e8a9063204f816e',1,'InterfaceDesktop::frmMain']]],
  ['marcartodasabaixo',['MarcarTodasAbaixo',['../class_interface_desktop_1_1frm_main.html#ad5c45cc5546fcc4d46fe1376af77f2ac',1,'InterfaceDesktop::frmMain']]],
  ['max',['Max',['../class_interface_desktop_1_1_analogico.html#ab9734eefc72ce67626ae1a91861fb1f6',1,'InterfaceDesktop.Analogico.Max()'],['../class_interface_desktop_1_1_analogico.html#af291a646c5b3a63288ba4e2774d8e0c5',1,'InterfaceDesktop.Analogico.Max(float Valor)']]],
  ['min',['Min',['../class_interface_desktop_1_1_analogico.html#a375b64f897e2d6d4da397700d28936d3',1,'InterfaceDesktop.Analogico.Min()'],['../class_interface_desktop_1_1_analogico.html#a7e710dcea7dea194a4e8ee1cc06bbc2c',1,'InterfaceDesktop.Analogico.Min(float Valor)']]]
];
