var searchData=
[
  ['feedservidor',['FeedServidor',['../class_interface_desktop_1_1_feed_servidor.html#a37a5c358ea661948c005f0e332c30933',1,'InterfaceDesktop.FeedServidor.FeedServidor()'],['../class_interface_desktop_1_1_feed_servidor.html#a60dcf21b33f9e5850367577298b66a11',1,'InterfaceDesktop.FeedServidor.FeedServidor(func funcao, int Indice)'],['../class_interface_desktop_1_1_feed_servidor.html#aa996d62c0a2b3e54fae997e947851a2d',1,'InterfaceDesktop.FeedServidor.FeedServidor(func funcao, int Indice, string Node, string Formato, Color cor, string nome)']]],
  ['formatatexto',['FormataTexto',['../class_interface_desktop_1_1frm_main.html#acfde0d5834d2cc97b277faaa95fbd807',1,'InterfaceDesktop::frmMain']]],
  ['frmcompara',['frmCompara',['../class_interface_desktop_1_1frm_compara.html#af89f2094a032545c4ec25b21ebdc5418',1,'InterfaceDesktop::frmCompara']]],
  ['frmcompara_5fformclosing',['frmCompara_FormClosing',['../class_interface_desktop_1_1frm_compara.html#a8d63031cf6a4b9ae67e12de4c9d4d6e2',1,'InterfaceDesktop::frmCompara']]],
  ['frmcompara_5fload',['frmCompara_Load',['../class_interface_desktop_1_1frm_compara.html#a9d9f1cb779284ee7473be3e04a1523d6',1,'InterfaceDesktop::frmCompara']]],
  ['frmconfig',['frmConfig',['../class_interface_desktop_1_1frm_config.html#ae4b1704de082e38216f564a694d50829',1,'InterfaceDesktop::frmConfig']]],
  ['frmconfig_5fload',['frmConfig_Load',['../class_interface_desktop_1_1frm_config.html#a340bdad64ac5e6629601845693d2c017',1,'InterfaceDesktop::frmConfig']]],
  ['frmgraficos',['frmGraficos',['../class_interface_desktop_1_1frm_graficos.html#a05de088cede82e8e7d352257720e5742',1,'InterfaceDesktop::frmGraficos']]],
  ['frmgraficos_5fformclosing',['frmGraficos_FormClosing',['../class_interface_desktop_1_1frm_graficos.html#ac2147557b3c8f14c28591e1b21a83ee8',1,'InterfaceDesktop::frmGraficos']]],
  ['frmgraficos_5fload',['frmGraficos_Load',['../class_interface_desktop_1_1frm_graficos.html#aa4d312754abd5a96e1c8c73f09e80d4e',1,'InterfaceDesktop::frmGraficos']]],
  ['frmlogin',['frmLogin',['../class_interface_desktop_1_1frm_login.html#a6ff1fe6b325f5b4491ea3d43a4323ee2',1,'InterfaceDesktop::frmLogin']]],
  ['frmlogin_5fload',['frmLogin_Load',['../class_interface_desktop_1_1frm_login.html#a510c96ccb5d68cfb83e94640b556da76',1,'InterfaceDesktop::frmLogin']]],
  ['frmmain',['frmMain',['../class_interface_desktop_1_1frm_main.html#a6783bf297230d4c03b027fd2eaab1bce',1,'InterfaceDesktop::frmMain']]],
  ['frmmain_5fformclosing',['frmMain_FormClosing',['../class_interface_desktop_1_1frm_main.html#addcc25b0a2ba27701a9c58071a45e689',1,'InterfaceDesktop::frmMain']]],
  ['frmmain_5fload',['frmMain_Load',['../class_interface_desktop_1_1frm_main.html#a4751885418de6806c221f157c89f4c41',1,'InterfaceDesktop::frmMain']]],
  ['func2str',['Func2str',['../class_interface_desktop_1_1frm_graficos.html#ab033ba47ca4810d3af875ad6b4cd7439',1,'InterfaceDesktop.frmGraficos.Func2str()'],['../class_interface_desktop_1_1frm_main.html#a40dcca66108454c87c92e7b1553b4cba',1,'InterfaceDesktop.frmMain.Func2str()']]]
];
