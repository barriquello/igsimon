var searchData=
[
  ['valor',['valor',['../class_interface_desktop_1_1_registro_c_s_v.html#a1c5ec7645607eb5edc98f5bf71566d4d',1,'InterfaceDesktop::RegistroCSV']]],
  ['valormaximo',['ValorMaximo',['../class_interface_desktop_1_1_analogico.html#a06bce013cfff29c166d91327bd8a5c62',1,'InterfaceDesktop.Analogico.ValorMaximo()'],['../class_interface_desktop_1_1_analogico.html#aca822e576c51b18b39607041f3da580a',1,'InterfaceDesktop.Analogico.ValorMaximo(float Maximo)']]],
  ['valorminimo',['ValorMinimo',['../class_interface_desktop_1_1_analogico.html#a53d66b0fce50671912ff15b225c74448',1,'InterfaceDesktop::Analogico']]],
  ['value',['Value',['../class_interface_desktop_1_1_analogico.html#acae325e4d0d2778e3f096ef2c69bd0ab',1,'InterfaceDesktop.Analogico.Value()'],['../class_interface_desktop_1_1_analogico.html#ad519bcdef7e851a966c47401c82b3e01',1,'InterfaceDesktop.Analogico.Value(float Valor)']]],
  ['verificasenha',['verificaSenha',['../class_interface_desktop_1_1frm_login.html#a84f3c6d22ec7a3c13ebe2f8fd2bcb6c2',1,'InterfaceDesktop::frmLogin']]]
];
