var searchData=
[
  ['centraliza',['Centraliza',['../class_interface_desktop_1_1_analogico.html#a11647ded3510d0102938afd98e339f3e',1,'InterfaceDesktop::Analogico']]],
  ['charttemperatura_5faxisviewchanged',['chartTemperatura_AxisViewChanged',['../class_interface_desktop_1_1frm_main.html#a3b33b206d7fe2f1fd24fd76ee95c19ad',1,'InterfaceDesktop::frmMain']]],
  ['charttemperatura_5fcursorpositionchanged',['chartTemperatura_CursorPositionChanged',['../class_interface_desktop_1_1frm_main.html#af57506f5bac5522ef86ff3c771818d7f',1,'InterfaceDesktop::frmMain']]],
  ['charttemperatura_5fmouseup',['chartTemperatura_MouseUp',['../class_interface_desktop_1_1frm_main.html#a1fc0d92defe662aefdff66c6e3f35341',1,'InterfaceDesktop::frmMain']]],
  ['chrgrafico1_5fcursorpositionchanged',['chrGrafico1_CursorPositionChanged',['../class_interface_desktop_1_1frm_compara.html#a2f0b523e6b6b249be075322e226bda02',1,'InterfaceDesktop::frmCompara']]],
  ['chrgrafico1_5fmouseup',['chrGrafico1_MouseUp',['../class_interface_desktop_1_1frm_compara.html#a188d3c6ea26bf20e437d850cc1a82bf2',1,'InterfaceDesktop::frmCompara']]],
  ['chrgrafico_5faxisviewchanged',['chrGrafico_AxisViewChanged',['../class_interface_desktop_1_1frm_graficos.html#ad92f298610d57f2a76df7f7339004b2e',1,'InterfaceDesktop::frmGraficos']]],
  ['chrgrafico_5fcursorpositionchanged',['chrGrafico_CursorPositionChanged',['../class_interface_desktop_1_1frm_graficos.html#a349f95af41b1df99aee06d9da025a1e9',1,'InterfaceDesktop::frmGraficos']]],
  ['chrgrafico_5fmouseup',['chrGrafico_MouseUp',['../class_interface_desktop_1_1frm_graficos.html#a78e8208b4c32c9fa83c343462a030a9c',1,'InterfaceDesktop::frmGraficos']]],
  ['criartabela',['CriarTabela',['../class_interface_desktop_1_1_banco_de_dados.html#ae6da73f29e0893c6e725414dfb17c48e',1,'InterfaceDesktop::BancoDeDados']]],
  ['csv2matriz',['CSV2Matriz',['../class_interface_desktop_1_1frm_main.html#ab53c30d545ead0870e7dda8cd52a5708',1,'InterfaceDesktop::frmMain']]]
];
