var searchData=
[
  ['analogico',['Analogico',['../class_interface_desktop_1_1_analogico.html#a5b92a2f012b83ac5cf64be2a0e5e4e44',1,'InterfaceDesktop::Analogico']]],
  ['analogico_5fload',['Analogico_Load',['../class_interface_desktop_1_1_analogico.html#a7a3bae69da9c66ccbe5adae0a544758f',1,'InterfaceDesktop::Analogico']]],
  ['analogico_5fsizechanged',['Analogico_SizeChanged',['../class_interface_desktop_1_1_analogico.html#ac77eb75546dbd739c597ca0efab00ac6',1,'InterfaceDesktop::Analogico']]],
  ['arquivocsv',['ArquivoCSV',['../class_interface_desktop_1_1_comandos_c_s_v.html#afea8735bf6e69dcb571c9e5a22f30d64',1,'InterfaceDesktop::ComandosCSV']]],
  ['arquivoparadata',['ArquivoParaData',['../class_interface_desktop_1_1frm_compara.html#a75b195ebf39093dc922109aac586eeac',1,'InterfaceDesktop.frmCompara.ArquivoParaData()'],['../class_interface_desktop_1_1frm_graficos.html#a10d01f2ec2c2cca7feed5f3b1fc2e553',1,'InterfaceDesktop.frmGraficos.ArquivoParaData()']]],
  ['atualizalabels',['AtualizaLabels',['../class_interface_desktop_1_1frm_main.html#ab0182d06aef6095999fdd628e63abde7',1,'InterfaceDesktop::frmMain']]],
  ['atualizalista',['AtualizaLista',['../class_interface_desktop_1_1frm_compara.html#aa8cfd08e114cf9e796bbe7d23d337b08',1,'InterfaceDesktop.frmCompara.AtualizaLista()'],['../class_interface_desktop_1_1frm_graficos.html#ab34f5e9bfff13124d9bcb6fa3155d488',1,'InterfaceDesktop.frmGraficos.AtualizaLista()']]]
];
