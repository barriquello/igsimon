var searchData=
[
  ['id',['id',['../class_interface_desktop_1_1_feed.html#a0c06184e0e99385f5b80e16bc0bedf6c',1,'InterfaceDesktop::Feed']]],
  ['indice',['indice',['../class_interface_desktop_1_1_feed_servidor.html#adb4b8160564f86930b4d325e8be150f2',1,'InterfaceDesktop::FeedServidor']]],
  ['indicefeed',['IndiceFeed',['../class_interface_desktop_1_1_feed_servidor.html#aa6e28578f5534cd6a217577e90c4cdfd',1,'InterfaceDesktop::FeedServidor']]],
  ['inicio',['Inicio',['../class_interface_desktop_1_1frm_graficos.html#aff65e9c476694c8a255a3d6931779994',1,'InterfaceDesktop::frmGraficos']]],
  ['inicio1',['Inicio1',['../class_interface_desktop_1_1frm_compara.html#acef7e0073c5e78661c7334871e73579e',1,'InterfaceDesktop::frmCompara']]],
  ['inicio2',['Inicio2',['../class_interface_desktop_1_1frm_compara.html#a6301a3e46170796fd0224597fcfe8486',1,'InterfaceDesktop::frmCompara']]],
  ['intnoleoalto',['intNOleoAlto',['../class_interface_desktop_1_1_global.html#aa2d72500d9d5efa4bfbc6ee02ac00caf',1,'InterfaceDesktop::Global']]],
  ['intnoleobaixo',['intNOleoBaixo',['../class_interface_desktop_1_1_global.html#adf6a84ba5b3d4f61e0a9993c60d172a0',1,'InterfaceDesktop::Global']]],
  ['intregistrosmaximo',['intRegistrosMAXIMO',['../class_interface_desktop_1_1_global.html#a8beeaa87a2fd86c367bff8690b13e10c',1,'InterfaceDesktop::Global']]],
  ['inttaxaatualizacao',['intTaxaAtualizacao',['../class_interface_desktop_1_1_global.html#a24130f61b194289861f0531854fe5b6a',1,'InterfaceDesktop::Global']]]
];
