var searchData=
[
  ['groupbox5',['groupBox5',['../class_interface_desktop_1_1frm_main.html#ae6d297f71de45f647fddb10409b85bfc',1,'InterfaceDesktop::frmMain']]],
  ['groupbox6',['groupBox6',['../class_interface_desktop_1_1frm_main.html#ae2a9982f0e11c143bead69f2c6cd5b9a',1,'InterfaceDesktop::frmMain']]]
];
