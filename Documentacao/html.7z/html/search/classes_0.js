var searchData=
[
  ['analogico',['Analogico',['../class_interface_desktop_1_1_analogico.html',1,'InterfaceDesktop']]]
];
