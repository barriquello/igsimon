var searchData=
[
  ['horario',['Horario',['../class_interface_desktop_1_1_registro_d_b.html#a3bc1197933edfb8d15ec7323e87101ce',1,'InterfaceDesktop::RegistroDB']]]
];
