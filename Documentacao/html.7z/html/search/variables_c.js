var searchData=
[
  ['nodetv1',['NodeTv1',['../class_interface_desktop_1_1_feed_servidor.html#af44aa02af3f4e28d72c1bb6a6bcfbd9b',1,'InterfaceDesktop::FeedServidor']]],
  ['nome',['Nome',['../class_interface_desktop_1_1_feed.html#abbabd9d818718d601591d70acdf783ba',1,'InterfaceDesktop::Feed']]],
  ['nomefeed',['NomeFeed',['../class_interface_desktop_1_1_feed_servidor.html#a3614df3d3bbfc5eac9e30884cb7d1b89',1,'InterfaceDesktop::FeedServidor']]],
  ['nometabela',['NomeTabela',['../class_interface_desktop_1_1_feed_servidor.html#a6a4995d4613553c7f94fde79d99baf76',1,'InterfaceDesktop::FeedServidor']]],
  ['numvars',['NumVars',['../class_interface_desktop_1_1_variaveis.html#aedc7e3796011f280e7089cf0e12185df',1,'InterfaceDesktop::Variaveis']]]
];
