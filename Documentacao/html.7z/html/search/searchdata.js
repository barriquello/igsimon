var indexSectionsWithContent =
{
  0: "_abcdefghijlmnoprstuv",
  1: "abcfgjrsuv",
  2: "i",
  3: "abcfgjprsuv",
  4: "abcdefgijlmprstuv",
  5: "_abcdefghijlnoprstuv",
  6: "f",
  7: "efinptv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Classes",
  2: "Namespaces",
  3: "Arquivos",
  4: "Funções",
  5: "Variáveis",
  6: "Enumerações",
  7: "Valores de enumerações"
};

