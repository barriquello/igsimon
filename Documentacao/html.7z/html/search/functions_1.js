var searchData=
[
  ['btnadduser_5fclick',['btnAddUser_Click',['../class_interface_desktop_1_1frm_config.html#ae9af2440ad665b645ea89b332c189b6e',1,'InterfaceDesktop::frmConfig']]],
  ['btnbuscar_5fclick',['btnBuscar_Click',['../class_interface_desktop_1_1frm_compara.html#abb827998e1056c75763793365e42cbe8',1,'InterfaceDesktop.frmCompara.btnBuscar_Click()'],['../class_interface_desktop_1_1frm_graficos.html#a17e1446a980c5a0dfdc7c331b3953b8d',1,'InterfaceDesktop.frmGraficos.btnBuscar_Click()']]],
  ['btncancelar_5fclick',['btnCancelar_Click',['../class_interface_desktop_1_1frm_config.html#acd290d5bfe44b28e11a54ce057a33af1',1,'InterfaceDesktop::frmConfig']]],
  ['btnconfig_5fclick',['btnConfig_Click',['../class_interface_desktop_1_1frm_login.html#a55a86577f1983c463a6bc4c2fa9f2fe0',1,'InterfaceDesktop::frmLogin']]],
  ['btnexcel_5fclick',['btnExcel_Click',['../class_interface_desktop_1_1frm_compara.html#a152a053c54485791960393fbe232e397',1,'InterfaceDesktop.frmCompara.btnExcel_Click()'],['../class_interface_desktop_1_1frm_graficos.html#a586a5167dbbd479f4bc3660b2f2bad25',1,'InterfaceDesktop.frmGraficos.btnExcel_Click()']]],
  ['btnoffline_5fclick',['btnOffline_Click',['../class_interface_desktop_1_1frm_login.html#a334561fd85e8c68b51faad1756ad90cd',1,'InterfaceDesktop::frmLogin']]],
  ['btnok_5fclick',['btnOK_Click',['../class_interface_desktop_1_1frm_config.html#af485cfa68711bd9033919ff82da77ad7',1,'InterfaceDesktop::frmConfig']]],
  ['btnonline_5fclick',['btnOnline_Click',['../class_interface_desktop_1_1frm_login.html#afc93e7c69bfc23cf9a0a62552f6a94c1',1,'InterfaceDesktop::frmLogin']]],
  ['btnservidor_5fclick',['btnServidor_Click',['../class_interface_desktop_1_1frm_config.html#a0ce8d91ca383c833fc6087ba701d5b2b',1,'InterfaceDesktop::frmConfig']]],
  ['buscadados',['BuscaDados',['../class_interface_desktop_1_1frm_main.html#aad5c1043bc7fad18382f0ac5b467c28b',1,'InterfaceDesktop.frmMain.BuscaDados(UInt32 Inicio, UInt32 Final)'],['../class_interface_desktop_1_1frm_main.html#ade0e03ed36b467cba8280b9bce84ee21',1,'InterfaceDesktop.frmMain.BuscaDados(DateTime dateTime1, DateTime dateTime2)']]],
  ['buscadadoscsv',['BuscaDadosCSV',['../class_interface_desktop_1_1frm_compara.html#a860ab3577a359ee92eac64d15c1056d2',1,'InterfaceDesktop.frmCompara.BuscaDadosCSV()'],['../class_interface_desktop_1_1frm_graficos.html#ae2bf5d7d0a60a46ee93d980b9c3a150c',1,'InterfaceDesktop.frmGraficos.BuscaDadosCSV()']]]
];
