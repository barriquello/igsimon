var searchData=
[
  ['interfacedesktop',['InterfaceDesktop',['../namespace_interface_desktop.html',1,'']]],
  ['properties',['Properties',['../namespace_interface_desktop_1_1_properties.html',1,'InterfaceDesktop']]]
];
