var searchData=
[
  ['redesenha',['Redesenha',['../class_interface_desktop_1_1_analogico.html#a7900e06acff6f4158190bb08a07ff45e',1,'InterfaceDesktop::Analogico']]],
  ['registromaisproximo',['RegistroMaisProximo',['../class_interface_desktop_1_1frm_compara.html#a5523c194b33d3c63cafdc335f5505f5a',1,'InterfaceDesktop::frmCompara']]]
];
