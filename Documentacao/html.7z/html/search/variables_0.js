var searchData=
[
  ['_5fmax',['_max',['../class_interface_desktop_1_1_analogico.html#a62daa3a2b8683827f42a51e94066eb3e',1,'InterfaceDesktop::Analogico']]],
  ['_5fmin',['_min',['../class_interface_desktop_1_1_analogico.html#aa86215624eb39cc9d64c7101eb58443a',1,'InterfaceDesktop::Analogico']]],
  ['_5fvalor',['_Valor',['../class_interface_desktop_1_1_analogico.html#aebb0288b2bee1af6393f2bba0db24e81',1,'InterfaceDesktop::Analogico']]],
  ['_5fvalormaximo',['_ValorMaximo',['../class_interface_desktop_1_1_analogico.html#a88ae2fa5c3f5570e96a8a17b2c88865e',1,'InterfaceDesktop::Analogico']]],
  ['_5fvalorminimo',['_ValorMinimo',['../class_interface_desktop_1_1_analogico.html#a84a4e75933b4c5491eb85dc6bc9adaf8',1,'InterfaceDesktop::Analogico']]]
];
