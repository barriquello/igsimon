var searchData=
[
  ['formsalvarexcel',['FormSalvarExcel',['../namespace_interface_desktop.html#a7c7f3613d058af20cc8fec119a16fb99',1,'InterfaceDesktop']]],
  ['func',['func',['../namespace_interface_desktop.html#af376de2af25fbcbc7f20f9846a7d4913',1,'InterfaceDesktop']]]
];
