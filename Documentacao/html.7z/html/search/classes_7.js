var searchData=
[
  ['salvarexcel',['SalvarExcel',['../class_interface_desktop_1_1_salvar_excel.html',1,'InterfaceDesktop']]],
  ['servidor',['Servidor',['../class_interface_desktop_1_1_servidor.html',1,'InterfaceDesktop']]]
];
