var searchData=
[
  ['valor',['Valor',['../class_interface_desktop_1_1_registro_c_s_v.html#a9ec99e061c09304e9316881c916793f1',1,'InterfaceDesktop::RegistroCSV']]],
  ['vars',['vars',['../class_interface_desktop_1_1frm_compara.html#a96c38997fcf36ed5d9af1ffb1f8ab198',1,'InterfaceDesktop.frmCompara.vars()'],['../class_interface_desktop_1_1frm_graficos.html#aa54b4e9c49d9540fd1042a6e9fa0751a',1,'InterfaceDesktop.frmGraficos.vars()']]]
];
