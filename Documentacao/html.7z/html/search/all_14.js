var searchData=
[
  ['valor',['valor',['../class_interface_desktop_1_1_registro_c_s_v.html#a1c5ec7645607eb5edc98f5bf71566d4d',1,'InterfaceDesktop.RegistroCSV.valor()'],['../class_interface_desktop_1_1_registro_c_s_v.html#a9ec99e061c09304e9316881c916793f1',1,'InterfaceDesktop.RegistroCSV.Valor()']]],
  ['valormaximo',['ValorMaximo',['../class_interface_desktop_1_1_analogico.html#a06bce013cfff29c166d91327bd8a5c62',1,'InterfaceDesktop.Analogico.ValorMaximo()'],['../class_interface_desktop_1_1_analogico.html#aca822e576c51b18b39607041f3da580a',1,'InterfaceDesktop.Analogico.ValorMaximo(float Maximo)']]],
  ['valorminimo',['ValorMinimo',['../class_interface_desktop_1_1_analogico.html#a53d66b0fce50671912ff15b225c74448',1,'InterfaceDesktop::Analogico']]],
  ['value',['Value',['../class_interface_desktop_1_1_analogico.html#acae325e4d0d2778e3f096ef2c69bd0ab',1,'InterfaceDesktop.Analogico.Value()'],['../class_interface_desktop_1_1_analogico.html#ad519bcdef7e851a966c47401c82b3e01',1,'InterfaceDesktop.Analogico.Value(float Valor)']]],
  ['variaveis',['Variaveis',['../class_interface_desktop_1_1_variaveis.html',1,'InterfaceDesktop']]],
  ['variaveis_2ecs',['Variaveis.cs',['../_variaveis_8cs.html',1,'']]],
  ['vars',['vars',['../class_interface_desktop_1_1frm_compara.html#a96c38997fcf36ed5d9af1ffb1f8ab198',1,'InterfaceDesktop.frmCompara.vars()'],['../class_interface_desktop_1_1frm_graficos.html#aa54b4e9c49d9540fd1042a6e9fa0751a',1,'InterfaceDesktop.frmGraficos.vars()']]],
  ['verificasenha',['verificaSenha',['../class_interface_desktop_1_1frm_login.html#a84f3c6d22ec7a3c13ebe2f8fd2bcb6c2',1,'InterfaceDesktop::frmLogin']]],
  ['vf',['Vf',['../namespace_interface_desktop.html#af376de2af25fbcbc7f20f9846a7d4913acd83025d45a01bf6fd4146332e5f5bbb',1,'InterfaceDesktop']]],
  ['vf0',['Vf0',['../namespace_interface_desktop.html#af376de2af25fbcbc7f20f9846a7d4913ae1d5cfe8aa59e79e3b615a3b219ecefb',1,'InterfaceDesktop']]],
  ['vl',['Vl',['../namespace_interface_desktop.html#af376de2af25fbcbc7f20f9846a7d4913a3f4596e91f642e1412a036fa5d672ca9',1,'InterfaceDesktop']]],
  ['vl0',['Vl0',['../namespace_interface_desktop.html#af376de2af25fbcbc7f20f9846a7d4913a8d2bb75e6025058d328bdaf888f1ed54',1,'InterfaceDesktop']]]
];
