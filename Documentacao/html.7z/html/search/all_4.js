var searchData=
[
  ['dglista',['dgLista',['../class_interface_desktop_1_1frm_compara.html#a35901f931b568a7e5456a5d8a63d42f0',1,'InterfaceDesktop::frmCompara']]],
  ['dispose',['Dispose',['../class_interface_desktop_1_1_analogico.html#adf121220a2aaf9a6c55476cb272df819',1,'InterfaceDesktop.Analogico.Dispose()'],['../class_interface_desktop_1_1frm_compara.html#ad14ba7c280c716c850eaead3c733486f',1,'InterfaceDesktop.frmCompara.Dispose()'],['../class_interface_desktop_1_1frm_config.html#a989b5e4fdf2a13956b844b602569f643',1,'InterfaceDesktop.frmConfig.Dispose()'],['../class_interface_desktop_1_1frm_graficos.html#aa6b9e2ac6480906294a4bee77494a827',1,'InterfaceDesktop.frmGraficos.Dispose()'],['../class_interface_desktop_1_1frm_login.html#a9fe801a021621d6b3401d1798249758d',1,'InterfaceDesktop.frmLogin.Dispose()'],['../class_interface_desktop_1_1frm_main.html#a91ff9be224445ded759681656e7015ae',1,'InterfaceDesktop.frmMain.Dispose()']]],
  ['dtdata2datetime',['DTData2DateTime',['../class_interface_desktop_1_1frm_main.html#a9b66af987e31cbb7b4102abd55739a7a',1,'InterfaceDesktop::frmMain']]],
  ['dtpfim',['dtpFim',['../class_interface_desktop_1_1frm_graficos.html#abb0e66eb9e1afe6ba0d8b12c316b1eaa',1,'InterfaceDesktop::frmGraficos']]],
  ['dtpinicio',['dtpInicio',['../class_interface_desktop_1_1frm_graficos.html#a13b52aa15cc1b9674092adae356781ac',1,'InterfaceDesktop::frmGraficos']]],
  ['dtpinicio1',['dtpInicio1',['../class_interface_desktop_1_1frm_compara.html#af870c1ce57ab8a33e5b95aef9db50980',1,'InterfaceDesktop::frmCompara']]],
  ['dtpinicio2',['dtpInicio2',['../class_interface_desktop_1_1frm_compara.html#aca9154e9de43566db348743011204593',1,'InterfaceDesktop::frmCompara']]]
];
