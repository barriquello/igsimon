var searchData=
[
  ['unix2time',['Unix2time',['../class_interface_desktop_1_1_uteis.html#ace0eb0315bc6df3a4c02b7a26286d40c',1,'InterfaceDesktop::Uteis']]]
];
