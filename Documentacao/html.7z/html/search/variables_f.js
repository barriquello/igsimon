var searchData=
[
  ['range',['range',['../class_interface_desktop_1_1_analogico.html#ad4c734c99aa24c56b21ed2bbf0b33d18',1,'InterfaceDesktop::Analogico']]],
  ['reg1',['reg1',['../class_interface_desktop_1_1frm_compara.html#a7f4c3d8db2e04db0ec92d3658ad4eb44',1,'InterfaceDesktop::frmCompara']]],
  ['registromaisatualizado',['RegistroMaisAtualizado',['../class_interface_desktop_1_1frm_main.html#a83d3b6e9ff253b687c448f7e2aceab19',1,'InterfaceDesktop::frmMain']]],
  ['registros',['Registros',['../class_interface_desktop_1_1frm_compara.html#a02d4f241cf56076a526648052e906cee',1,'InterfaceDesktop.frmCompara.Registros()'],['../class_interface_desktop_1_1frm_graficos.html#aae328f61cb23da13ad82fc3f1ffec9e5',1,'InterfaceDesktop.frmGraficos.Registros()'],['../class_interface_desktop_1_1frm_main.html#a2e5913f2c4f27fa70d2ee692337a0335',1,'InterfaceDesktop.frmMain.Registros()']]]
];
