var searchData=
[
  ['analogico_2ecs',['Analogico.cs',['../_analogico_8cs.html',1,'']]],
  ['analogico_2edesigner_2ecs',['Analogico.Designer.cs',['../_analogico_8_designer_8cs.html',1,'']]],
  ['assemblyinfo_2ecs',['AssemblyInfo.cs',['../_assembly_info_8cs.html',1,'']]]
];
