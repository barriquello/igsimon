var searchData=
[
  ['time',['time',['../class_interface_desktop_1_1_registro_c_s_v.html#a2ef31f5aae7eae36672a359707f65482',1,'InterfaceDesktop::RegistroCSV']]],
  ['time2unix',['Time2Unix',['../class_interface_desktop_1_1frm_compara.html#ab76fea0c342406830c85935b5be9ce12',1,'InterfaceDesktop.frmCompara.Time2Unix()'],['../class_interface_desktop_1_1frm_graficos.html#a66c0c8a2b2de5f8d41cadef5c3e8950c',1,'InterfaceDesktop.frmGraficos.Time2Unix()'],['../class_interface_desktop_1_1_uteis.html#aae232ceac85855cc5df943d22dc33d9e',1,'InterfaceDesktop.Uteis.Time2Unix()']]],
  ['timerrelogio_5ftick',['timerRelogio_Tick',['../class_interface_desktop_1_1frm_main.html#a358548b33417e438eacbcc4254ef24b1',1,'InterfaceDesktop::frmMain']]],
  ['timeunix',['timeUnix',['../class_interface_desktop_1_1_registro_c_s_v.html#a2a9a1f09988a07546b5d09891083a661',1,'InterfaceDesktop::RegistroCSV']]],
  ['tmrblink_5ftick',['tmrBlink_Tick',['../class_interface_desktop_1_1frm_main.html#afae5b6f06742c417c6ab4d638b494035',1,'InterfaceDesktop::frmMain']]],
  ['tmrgraficos_5ftick',['tmrGraficos_Tick',['../class_interface_desktop_1_1frm_main.html#a379fa91b9873a522d6ac75be3417072b',1,'InterfaceDesktop::frmMain']]],
  ['tmrrelogio_5ftick',['tmrRelogio_Tick',['../class_interface_desktop_1_1frm_compara.html#a2abdf856e87d1772eaab7147e0a7ba61',1,'InterfaceDesktop.frmCompara.tmrRelogio_Tick()'],['../class_interface_desktop_1_1frm_graficos.html#a11d46a7527af41fd49a714e385443fea',1,'InterfaceDesktop.frmGraficos.tmrRelogio_Tick()']]],
  ['tooconfig_5fclick',['tooConfig_Click',['../class_interface_desktop_1_1frm_main.html#aa924cdd8b161bf9afc302aade6b1d69b',1,'InterfaceDesktop::frmMain']]],
  ['toolcomparar_5fclick',['toolComparar_Click',['../class_interface_desktop_1_1frm_main.html#a01491099d51bc57e212a2e670a911b6b',1,'InterfaceDesktop::frmMain']]],
  ['toolexcel_5fclick',['toolExcel_Click',['../class_interface_desktop_1_1frm_main.html#a9b40e5ad84ac0039962324206acb7acb',1,'InterfaceDesktop::frmMain']]],
  ['toolgraficos_5fclick',['toolGraficos_Click',['../class_interface_desktop_1_1frm_main.html#a9c8fcae51c3ee13e08423622648e3afc',1,'InterfaceDesktop::frmMain']]],
  ['toolstripbutton1_5fclick',['toolStripButton1_Click',['../class_interface_desktop_1_1frm_login.html#a4d187308856a17d7b5adaf1b6d399bfd',1,'InterfaceDesktop::frmLogin']]],
  ['toolstripcombobox1_5ftextchanged',['toolStripComboBox1_TextChanged',['../class_interface_desktop_1_1frm_main.html#a1f47ad52ec8c95f9289eb8b6d9e4c29d',1,'InterfaceDesktop::frmMain']]],
  ['tv1_5faftercheck',['tv1_AfterCheck',['../class_interface_desktop_1_1frm_main.html#aeb51d19a85143bb6e87315cc23833c27',1,'InterfaceDesktop::frmMain']]]
];
