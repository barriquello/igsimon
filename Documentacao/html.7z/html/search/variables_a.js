var searchData=
[
  ['janeladetempo',['JanelaDeTempo',['../class_interface_desktop_1_1frm_main.html#a127fb011513aaad2297dbdda1d53b494',1,'InterfaceDesktop::frmMain']]],
  ['janelatempo',['JanelaTempo',['../class_interface_desktop_1_1frm_compara.html#a890485bdc53e74d5253870955643f454',1,'InterfaceDesktop::frmCompara']]]
];
