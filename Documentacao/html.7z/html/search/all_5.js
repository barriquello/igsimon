var searchData=
[
  ['en',['En',['../namespace_interface_desktop.html#af376de2af25fbcbc7f20f9846a7d4913a6d416f7786dbe588eaa6ab48666588d1',1,'InterfaceDesktop']]],
  ['en0',['En0',['../namespace_interface_desktop.html#af376de2af25fbcbc7f20f9846a7d4913a976bc2c7f337da7c9cc3802995972f09',1,'InterfaceDesktop']]],
  ['encerrando',['Encerrando',['../class_interface_desktop_1_1frm_main.html#a38d651f06adde6937ca5e06ebbffa084',1,'InterfaceDesktop::frmMain']]],
  ['escalatamanho',['EscalaTamanho',['../class_interface_desktop_1_1_analogico.html#a0f2272a68dcf19acc13727cfc8e3fac0',1,'InterfaceDesktop::Analogico']]],
  ['escolhecor',['escolheCor',['../class_interface_desktop_1_1frm_compara.html#a0d0eb11fd14d2b7eb1ea7b1d94db2bd4',1,'InterfaceDesktop::frmCompara']]],
  ['exibefloat',['ExibeFloat',['../class_interface_desktop_1_1frm_compara.html#ae89714a1132c66306b0734ef214807eb',1,'InterfaceDesktop::frmCompara']]]
];
