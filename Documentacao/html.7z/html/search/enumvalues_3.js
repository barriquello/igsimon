var searchData=
[
  ['ni',['Ni',['../namespace_interface_desktop.html#af376de2af25fbcbc7f20f9846a7d4913aa26e174e330476756d2601ea5368aec3',1,'InterfaceDesktop']]],
  ['ni0',['Ni0',['../namespace_interface_desktop.html#af376de2af25fbcbc7f20f9846a7d4913a3cb6ddf32d4ba16a14adb6d0990fabea',1,'InterfaceDesktop']]]
];
